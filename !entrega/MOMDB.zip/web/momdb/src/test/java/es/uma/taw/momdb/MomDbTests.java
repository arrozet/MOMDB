package es.uma.taw.momdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MomDbTests {

    @Test
    void contextLoads() {
    }

}
