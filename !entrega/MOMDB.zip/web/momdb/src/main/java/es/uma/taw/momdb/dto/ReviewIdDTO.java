package es.uma.taw.momdb.dto;

import lombok.Data;

/*
 * @author Artur797 (Artur Vargas)
 */
@Data
public class ReviewIdDTO {
    private Integer movieId;
    private Integer userId;
} 