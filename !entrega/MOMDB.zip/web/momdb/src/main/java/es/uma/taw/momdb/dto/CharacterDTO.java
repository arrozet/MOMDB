package es.uma.taw.momdb.dto;

import lombok.Data;

/*
 * @author projectGeorge (Jorge Repullo - 69.2%), Artur797 (Artur Vargas - 30.8%)
 */
@Data
public class CharacterDTO {
    private int id = -1;
    private String characterName;
}
