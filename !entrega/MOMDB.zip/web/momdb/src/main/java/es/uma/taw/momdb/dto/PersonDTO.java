package es.uma.taw.momdb.dto;

import lombok.Data;

/*
 * @author Artur797 (Artur Vargas)
 */

@Data
public class PersonDTO {
    private Integer id = -1;
    private String name;
} 