package es.uma.taw.momdb.dto;

/*
 * @author Artur797 (Artur Vargas - 55.6%), arrozet (Rubén Oliva - 44.4%)
 */
public interface DTO<DTOClass> {
    public DTOClass toDTO ();
}
